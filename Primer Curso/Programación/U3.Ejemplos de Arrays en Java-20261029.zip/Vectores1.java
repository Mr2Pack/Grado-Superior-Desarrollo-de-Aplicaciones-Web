/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author jg.fructuosocano
 */
public class Vectores1 {
    
    public static void main(String[] Args){
        
        //Definimos los vectores
        int n=4;
        int m=n;
        
        int v1[];
        int [] v2;
        
        //Instanciamos los vectores
        v1=new int[n];
        v2=new int[m];
        
        //Rellenamos los vectores con valores aleatorios entre 
        //máximo y mínimo
        byte aleatorio,minimo=1,maximo=10;
        
        for(int i=0;i<v1.length;i++){    
            aleatorio = (byte)(minimo + (Math.random() * (maximo - minimo)));
            v1[i]=aleatorio;
        }    
        
        for(int i=0;i<v2.length;i++){    
            aleatorio = (byte)(minimo + (Math.random() * (maximo - minimo)));
            v2[i]=aleatorio;
        }    
        
        
        //Visualizamos los vectores
        System.out.println("Vector v1");
        for(int i=0;i<v1.length;i++){    
            System.out.print(v1[i]+" ");
        }    
        System.out.print("\n\n");
        
        System.out.println("Vector v2");
        for(int i=0;i<v2.length;i++){    
            System.out.print(v2[i]+" ");
        }    
        System.out.print("\n\n");
        
        
        //Copiamos el vector v1 dentro de v2
        //Ambos vectores deben tener la misma cantida de elementos
        for(int i=0;i<v1.length;i++) v2[i]=v1[i];   
           
        //Visualizamos los vectores después de hacer la copia
        System.out.println("Vectores después de realizar la copia"+
                "\nVector v1");
        for(int i=0;i<v1.length;i++){    
            System.out.print(v1[i]+" ");
        }    
        System.out.print("\n\n");
        
        System.out.println("Vector v2");
        for(int i=0;i<v2.length;i++){    
            System.out.print(v2[i]+" ");
        }    
        System.out.print("\n\n");
        
        
        //Copiamos el vector v1 dentro de v2
        //haciendo uso del método System.arraycopy
        System.arraycopy(v1,0,v2,0,v1.length);
           
        //Visualizamos los vectores después de hacer la copia
        System.out.println("Vectores después de realizar la copia"+
                "\nVector v1");
        for(int i=0;i<v1.length;i++){    
            System.out.print(v1[i]+" ");
        }    
        System.out.print("\n\n");
        
        System.out.println("Vector v2");
        for(int i=0;i<v2.length;i++){    
            System.out.print(v2[i]+" ");
        }    
        System.out.print("\n\n");
        
        
        /*Si intentamos copiar un vector de 4 componentes en un 
        vector de 3 componentes
        
        int v3[]=new int[3];
        System.arraycopy(v1,0,v3,0,v1.length);
        
        Se producirá un error:

        Exception in thread "main" java.lang.ArrayIndexOutOfBoundsException: 
        arraycopy: last destination index 4 out of bounds for int[3]
	at java.base/java.lang.System.arraycopy(Native Method)
        */
        
    }
            

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author jg.fructuosocano
 */

import java.util.Scanner;

public class Vectores {
    
    public static void main(String[] Args){
        
        int n=3,suma=0,nota;
        int notas[]=new int[n];
        float media=0f;
        Scanner teclado=new Scanner(System.in);
        
        
        for(int i=0;i<notas.length;i++){
            System.out.println("Introduce una nota ");
            nota=teclado.nextInt();
            notas[i]=nota;
            //notas[i]=teclado.nextInt();
        }    

        //for(int i=0;i<notas.length;i++)
        //    System.out.print(notas[i]+"  ");

        
        for(int i=0;i<notas.length;i++)
            suma+=notas[i];
        
        media=(float)suma/notas.length;
        System.out.println("La media es "+media+" redondeada "+Math.round(media));
         
     
        switch (Math.round(media)){
            case 0:
            case 1:
            case 2:
            case 3:
            case 4: System.out.println("Suspenso"); break;
            case 5: System.out.println("Aprobado"); break;
            case 6: System.out.println("Bien"); break;
            case 7:
            case 8: System.out.println("Notable"); break;
            case 9:
            case 10: System.out.println("Sobresaliente"); break;
            default: System.out.println("Caso no contemplado"); break;  
                
            
        }
        
    }
    
}
